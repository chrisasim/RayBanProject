export class User {
 constructor(
  public name: string,
  public surname: string,
  public notification: boolean,
  public phonenumber: number,
  public email: string
 ){}
 
}

import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { EnrollmentService} from './enrollment.service';

@Component({
  selector: 'app-angular',
  templateUrl: './angular.component.html',
  styleUrls: ['./angular.component.css']
})
export class AngularComponent implements OnInit {

   topics=['Angular', 'React', 'Vue']

  constructor(private _enrollmentService: EnrollmentService) { }

  ngOnInit(): void {
  }


 onSubmit()
  {


console.log(this.userModel)

 this._enrollmentService.enroll(this.userModel)
 .subscribe(
   data => console.log('Success!', data), 
   error => console.error('Error!', error)
 )


}


  userModel = new User('Rob' , 'Smith', true , 3453453, 'chrisasimi@hotmail.com');

}


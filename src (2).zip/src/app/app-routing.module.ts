import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {UserComponent} from './user/user.component';
import { AngularComponent} from './angular/angular.component';

const routes: Routes = [
   {path:'user', component:UserComponent},
   {path: 'angular', component:AngularComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {




 }
